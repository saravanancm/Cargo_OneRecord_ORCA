
$(document).ready(function() {
    console.log('Inside the one login.js');
});

inputUserObj = {userName: "", userPwd: ""}

function myfunction() {
     console.log("InputUserObj : ");

}

function myfunction() {
    console.log("welcome to Javatpoint   :  " + this.document.querySelector('input[data-name="userName"]').value);
    if(window.event.target.dataset.name === 'userName'){
        this.inputUserObj.userName=this.document.querySelector('input[data-name="userName"]').value;
    }
    if(window.event.target.dataset.name === 'userPwd'){
        this.inputUserObj.userPwd=this.document.querySelector('input[data-name="userPwd"]').value;
    }
    console.log("InputUserObj : " + JSON.stringify(this.inputUserObj));
}

function authenticateLogin() {
    //let loginInput = JSON.parse(JSON.stringify(this.inputUserObj))
	
	if(this.inputUserObj.userName === 'dohagha' && this.inputUserObj.userPwd === 'dohagha'){
		window.location.href = "http://localhost:9090/dohaHome.html";
	} else if(this.inputUserObj.userName === 'dhakagha' && this.inputUserObj.userPwd === 'dhakagha'){
		window.location.href = "http://localhost:9090/dhakaHome.html";
	} else if(this.inputUserObj.userName === 'fragha' && this.inputUserObj.userPwd === 'fragha'){
		window.location.href = "http://localhost:9090/fraHome.html";
	} else if(this.inputUserObj.userName === 'hkggha' && this.inputUserObj.userPwd === 'hkggha'){
		window.location.href = "http://localhost:9090/hkgHome.html";
	} else {
		window.location.href = "http://localhost:9090/errorPage.html";
	}
    
    //window.location.href = "http://localhost:9090/dhakaHome.html";
    
    $.ajax({type: "POST",
        url: "/userLogin",
        data:JSON.stringify(this.inputUserObj),
        contentType : 'application/json; charset=utf-8',
        dataType : 'json',
        success: function (response) {
            console.log("InputUserObj : " + response);
        }
    });
}