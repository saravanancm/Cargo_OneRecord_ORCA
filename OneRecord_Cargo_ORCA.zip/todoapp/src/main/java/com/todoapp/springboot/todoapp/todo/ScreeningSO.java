package com.todoapp.springboot.todoapp.todo;

public class ScreeningSO {
	private Long screenigUniqueId;
	private Long screenigId;
	private String airportCode;
	private String screeningType;
	private Boolean screeningRequire;
	private Boolean screeningCompleted;
	public ScreeningSO() {
		// TODO Auto-generated constructor stub
	}
	
	public ScreeningSO(Long screenigId, String airportCode, String screeningType, Boolean screeningRequire, Boolean screeningCompleted) {
		super();
		this.screenigId = screenigId;
		this.airportCode = airportCode;
		this.screeningType = screeningType;
		this.screeningRequire = screeningRequire;
		this.screeningCompleted = screeningCompleted;
	}
	
	public Long getScreenigId() {
		return screenigId;
	}
	public void setScreenigId(Long screenigId) {
		this.screenigId = screenigId;
	}
	public String getAirportCode() {
		return airportCode;
	}
	public void setAirportCode(String airportCode) {
		this.airportCode = airportCode;
	}
	public String getScreeningType() {
		return screeningType;
	}
	public void setScreeningType(String screeningType) {
		this.screeningType = screeningType;
	}
	public Boolean getScreeningRequire() {
		return screeningRequire;
	}
	public void setScreeningRequire(Boolean screeningRequire) {
		this.screeningRequire = screeningRequire;
	}
	public Boolean getScreeningCompleted() {
		return screeningCompleted;
	}
	public void setScreeningCompleted(Boolean screeningCompleted) {
		this.screeningCompleted = screeningCompleted;
	}
	public Long getScreenigUniqueId() {
		return screenigUniqueId;
	}
	public void setScreenigUniqueId(Long screenigUniqueId) {
		this.screenigUniqueId = screenigUniqueId;
	}
	
}
