package com.todoapp.springboot.todoapp.todo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestParam;

@Service
public class TodoService {

	private static List<Todo> todos;
	private static Long todId = Long.valueOf(1001);
	static {
		todos = new ArrayList<>();
		todos.add(new Todo(todId++, "Learn Spring Boot", "sromkar", LocalDate.now().plusDays(30), LocalDate.now(), false));
		todos.add(new Todo(todId++, "Learn Automation tools", "sromkar", LocalDate.now().plusDays(30), LocalDate.now(), false));
		
	}
	
	public List<Todo> findByUserName(String userName){
		return todos;
	}
	
	public void addNewTodo(String description, String userName, LocalDate targetDate, LocalDate createdDate,
			boolean done) {
		todos.add(new Todo(todId++, description, userName, targetDate, createdDate, done));
	}
	
	public void deleteById(Long id) {
		System.out.println("Inside deleteById");
		Predicate<? super Todo> predicate = todo -> todo.getId().compareTo(id) == 0;
		todos.removeIf(predicate); 
	}
	
	public Todo findById(Long id) {
		System.out.println("Inside findById");
		Predicate<? super Todo> predicate = todo -> todo.getId().compareTo(id) == 0;
		Todo todo = todos.stream().filter(predicate).findFirst().get();
		return todo;
	}
	
	public void updaetTodo(Todo inputTodo) {
		deleteById(inputTodo.getId());
		todos.add(inputTodo);
	}
}

