package com.todoapp.springboot.todoapp.todo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtil<T> {

	public T convertJsonToObject (String jsonText, Class<T> clazz) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
			mapper.setDateFormat(df);
			return mapper.readValue(jsonText, clazz);
		}
		catch(Exception e) {
			
		}
		return null;
	}
	
}
