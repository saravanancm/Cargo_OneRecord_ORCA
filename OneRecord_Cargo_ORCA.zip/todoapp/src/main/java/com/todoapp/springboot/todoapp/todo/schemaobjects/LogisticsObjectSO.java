package com.todoapp.springboot.todoapp.todo.schemaobjects;

import ioinformarics.oss.jackson.module.jsonld.annotation.JsonldId;
import ioinformarics.oss.jackson.module.jsonld.annotation.JsonldLink;
import ioinformarics.oss.jackson.module.jsonld.annotation.JsonldNamespace;
import ioinformarics.oss.jackson.module.jsonld.annotation.JsonldProperty;
import ioinformarics.oss.jackson.module.jsonld.annotation.JsonldResource;
import ioinformarics.oss.jackson.module.jsonld.annotation.JsonldType;

@JsonldResource
@JsonldNamespace(name = "s", uri = "https://onerecord.iata.org/ns/cargo")
@JsonldType("s:LogisticsObject")
//@JsonldLink(rel = "s:knows", name = "knows", href = "http://example.com/person/2345")
public class LogisticsObjectSO {
	 @JsonldId
	 private String id;
	 @JsonldProperty("s:securityDeclaration")
	 private SecurityDeclaration securityDeclaration;
	 

}
