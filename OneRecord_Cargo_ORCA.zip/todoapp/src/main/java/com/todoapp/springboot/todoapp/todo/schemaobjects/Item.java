package com.todoapp.springboot.todoapp.todo.schemaobjects;

import java.io.Serializable;

public class Item extends LogisticsObjectSO implements Serializable{

	private static final long serialVersionUID = 1l;

}
