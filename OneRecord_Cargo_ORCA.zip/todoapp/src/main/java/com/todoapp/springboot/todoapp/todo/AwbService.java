package com.todoapp.springboot.todoapp.todo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import org.springframework.stereotype.Service;

@Service
public class AwbService {

	private static Map<String, List<String>> screenigMandateMap=new HashMap<String, List<String>>();
	private static List<AwbResponse> awbs;
	private static Long awbId = Long.valueOf(1001);
	private static Long fltId = Long.valueOf(2001);
	private static Long screenigUniqueId = Long.valueOf(3001);
	static {
		
		List<String> dacScreening=new ArrayList<String>();
		dacScreening.add("X-Ray Equipment");
		dacScreening.add("PHS - Physical Inspection");
		dacScreening.add("VCK Visual Check");
		screenigMandateMap.put("DAC", dacScreening);
		
		
		List<String> dohScreening=new ArrayList<String>();
		dohScreening.add("X-Ray Equipment");
		dohScreening.add("MDE - Metal Detection Equipment");
		screenigMandateMap.put("DOH", dohScreening);
		
		List<String> hkgScreening=new ArrayList<String>();
		hkgScreening.add("X-Ray Equipment");
		hkgScreening.add("PHS - Physical Inspection");
		hkgScreening.add("VCK Visual Check");
		screenigMandateMap.put("HKG", hkgScreening);
		
		awbs = new ArrayList<AwbResponse>();
		AwbResponse awb1=new AwbResponse(awbId++, "MAWB", "157", "11111111", "10", "1000.00", "2.000", "DAC", "FRA", "General Cargo", "GCR");
		awb1.getFlights().add(new AwbFlightDtls(fltId++, "QR", "0123", "DAC", "DOH", "15-Dec-2023 15:00", "15-Dec-2023 21:00", Long.valueOf(1), Boolean.TRUE));
		awb1.getFlights().add(new AwbFlightDtls(fltId++, "QR", "0456", "DOH", "FRA", "16-Dec-2023 04:00", "16-Dec-2023 06:00", Long.valueOf(2), Boolean.TRUE));
		awbs.add(awb1);
		for(AwbFlightDtls fltInfo : awb1.getFlights()) {
			fltInfo.setScreeeningCheckList(getApplicableScreening(fltInfo.getFromApt()));
		}
		AwbResponse awb2=new AwbResponse(awbId++, "MAWB", "157", "12345678", "20", "2000.00", "4.000", "DAC", "FRA", "General Cargo", "GCR");
		awb2.getFlights().add(new AwbFlightDtls(fltId++, "QR", "0123", "DAC", "DOH", "16-Dec-2023 15:00", "16-Dec-2023 21:00", Long.valueOf(1), Boolean.TRUE));
		awb2.getFlights().add(new AwbFlightDtls(fltId++, "QR", "0456", "DOH", "FRA", "17-Dec-2023 04:00", "17-Dec-2023 06:00", Long.valueOf(2), Boolean.TRUE));
		for(AwbFlightDtls fltInfo : awb2.getFlights()) {
			fltInfo.setScreeeningCheckList(getApplicableScreening(fltInfo.getFromApt()));
		}
		awbs.add(awb2);
		
		AwbResponse awb3=new AwbResponse(awbId++, "MAWB", "157", "97412345", "20", "2000.00", "4.000", "DAC", "FRA", "General Cargo", "GCR");
		awb3.getFlights().add(new AwbFlightDtls(fltId++, "QR", "8403", "DAC", "DOH", "26-Nov-2023 15:00", "26-Nov-2023 21:00", Long.valueOf(1), Boolean.TRUE));
		awb3.getFlights().add(new AwbFlightDtls(fltId++, "QR", "8203", "DOH", "FRA", "27-Nov-2023 04:00", "27-Dec-2023 06:00", Long.valueOf(2), Boolean.TRUE));
		for(AwbFlightDtls fltInfo : awb3.getFlights()) {
			fltInfo.setScreeeningCheckList(getApplicableScreening(fltInfo.getFromApt()));
		}
		awbs.add(awb3);

	}

	public static List<ScreeningSO> getApplicableScreening(String airportCode){
		List<ScreeningSO> responseList = new ArrayList<ScreeningSO>();
		List<String> appliScreening = screenigMandateMap.get(airportCode);
		Long screeningId = Long.valueOf(1);
		for (String string : appliScreening) {
			ScreeningSO so = new ScreeningSO(screeningId++, airportCode, string, Boolean.TRUE, Boolean.FALSE);
			screenigUniqueId++;
			so.setScreenigUniqueId(screenigUniqueId);
			responseList.add(so);
		}
		return responseList;
	}
	
	public void prepareScreeningDom(AwbResponse awbInfo, String loginPlace) {
		StringBuilder sb = new StringBuilder();
		Boolean canSeeApt=Boolean.TRUE;
		for(AwbFlightDtls fltInfo : awbInfo.getFlights()) {
			
			if(canSeeApt == true && fltInfo.getScrreningReq() == true && fltInfo.getScreeeningCheckList() != null && fltInfo.getScreeeningCheckList().size() > 0) {
				sb.append("<div class=\"col\"><table class=\"table table-striped table-hover table-bordered\"><thead><tr><th scope=\"col\">#</th><th scope=\"col\">Airport</th>"+
						"<th scope=\"col\">Screening Method</th><th scope=\"col-auto\">Status</th></tr>");
				
				if(!loginPlace.equals(awbInfo.getDest())) {
					sb.append("<th scope=\"col-auto\">Action</th>");
				}
				sb.append("</thead><tbody>");
				for(ScreeningSO screeningInfo : fltInfo.getScreeeningCheckList()) {
					String screenrow="";
					String status = screeningInfo.getScreeningCompleted() ? "Screened" : "Screened pending";
					String classCss=screeningInfo.getScreeningCompleted() ? "class=\"badge bg-success\"" : "class=\"badge bg-warning text-dark\"";
					if(loginPlace.equals(fltInfo.getFromApt())) {
						String approveStr="<td><button type=\"button\" class=\"btn btn-primary\" data-name=ACT-"+screeningInfo.getScreenigUniqueId()+"  onclick=\"updateStatus("+screeningInfo.getScreenigUniqueId()+")\">Complete</button></td>";
						screenrow="<tr><th scope=\"row\">"+screeningInfo.getScreenigId()+"</th><td>"+screeningInfo.getAirportCode()+"</td><td>"+screeningInfo.getScreeningType()+"</td><td><span "+classCss+" data-name=\"xray1\">"+status+"</span></td>"+approveStr+"</tr>";
					} else {
						String approveStr="";
						screenrow="<tr><th scope=\"row\">"+screeningInfo.getScreenigId()+"</th><td>"+screeningInfo.getAirportCode()+"</td><td>"+screeningInfo.getScreeningType()+"</td><td><span "+classCss+" data-name=\"xray1\">"+status+"</span></td>"+approveStr+"</tr>";
					
					}
					
					sb.append(screenrow);
				}
				sb.append("</tbody></table></div>");
			}
			if(fltInfo.getFromApt().equals(loginPlace) && !fltInfo.getToApt().equals(loginPlace)) {
				canSeeApt=Boolean.FALSE;
			}
			if(fltInfo.getFromApt().equals(loginPlace)) {
				Boolean mandateComplted=Boolean.TRUE;
				for(ScreeningSO screeningInfo : fltInfo.getScreeeningCheckList()) {
					if(mandateComplted == true && screeningInfo.getScreeningCompleted() == false) {
						mandateComplted=Boolean.FALSE;
					}
				}
				awbInfo.setMandateComplted(mandateComplted);
			}
			
			
			
		}
		if(loginPlace.equals(awbInfo.getDest())) {
			Boolean mandateComplted=Boolean.TRUE;
			for(AwbFlightDtls fltInfo : awbInfo.getFlights()) {
				for(ScreeningSO screeningInfo : fltInfo.getScreeeningCheckList()) {
					if(mandateComplted == true && screeningInfo.getScreeningCompleted() == false) {
						mandateComplted=Boolean.FALSE;
					}
				}
			}
			awbInfo.setMandateComplted(mandateComplted);
		}	
		
		
		awbInfo.setScreeningDom(sb.toString());
	}
	
	
	
	public AwbResponse getAwbDetails(String awbPrfx, String awbNumber){
		System.out.println("Inside findById");
		Predicate<? super AwbResponse> predicate = todo -> (todo.getAwbNumber().equals(awbNumber) && todo.getAwbPrfx().equals(awbPrfx));
		AwbResponse awb = awbs.stream().filter(predicate).findFirst().get();
		return awb;
	}
	
	public AwbResponse updateDetails(String awbPrfx, String awbNumber, Long screenigUniqueId){
		System.out.println("Inside findById");
		Predicate<? super AwbResponse> predicate = todo -> (todo.getAwbNumber().equals(awbNumber) && todo.getAwbPrfx().equals(awbPrfx));
		AwbResponse awb = awbs.stream().filter(predicate).findFirst().get();
		for(AwbFlightDtls fltInfo : awb.getFlights()) {
			for(ScreeningSO screeningInfo : fltInfo.getScreeeningCheckList()) {
				if(screeningInfo.getScreenigUniqueId().compareTo(screenigUniqueId) == 0) {
					screeningInfo.setScreeningCompleted(Boolean.TRUE);
				}
			}
		}
		return awb;
	}
	
	public void checkMandateStatus() {
		
	}
}
