package com.todoapp.springboot.todoapp.todo.schemaobjects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonPropertyOrder({"@id","@type"})
@JsonIgnoreProperties({"@type"})
@JsonTypeName("SecurityDeclaration")
public class SecurityDeclaration extends LogisticsObjectSO implements Serializable{

	private static final long serialVersionUID = 1l;
	
	private String additionalSecurityInformation;
	private String screeningMethod;
	public String getAdditionalSecurityInformation() {
		return additionalSecurityInformation;
	}
	public void setAdditionalSecurityInformation(String additionalSecurityInformation) {
		this.additionalSecurityInformation = additionalSecurityInformation;
	}
	public String getScreeningMethod() {
		return screeningMethod;
	}
	public void setScreeningMethod(String screeningMethod) {
		this.screeningMethod = screeningMethod;
	}
	
}
