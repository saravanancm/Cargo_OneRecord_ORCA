package com.todoapp.springboot.todoapp.todo.schemaobjects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonPropertyOrder({"@context", "@id","@type"})
@JsonIgnoreProperties({"@type"})
@JsonTypeName("Shipment")
public class Shipment extends LogisticsObjectSO implements Serializable{

	private static final long serialVersionUID = 1l;
	
	private String goodsDescription;
}
