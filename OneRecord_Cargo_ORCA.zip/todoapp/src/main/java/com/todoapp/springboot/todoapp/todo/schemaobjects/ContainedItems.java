package com.todoapp.springboot.todoapp.todo.schemaobjects;

import java.io.Serializable;

public class ContainedItems extends Piece implements Serializable{

	private static final long serialVersionUID = 1l;

}
