package com.todoapp.springboot.todoapp.todo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.validation.Valid;

@Controller
public class TodoController {

	@Autowired
	private TodoService todoService;
	
	@RequestMapping("userTodos")
	public String getAllTodos(ModelMap model) {
		List<Todo> todos = todoService.findByUserName("sraomkar");
		model.addAttribute("todos", todos);
		return "userTodos";
	}
	
	@RequestMapping(value = "addTodo", method = RequestMethod.GET)
	public String addTodoPage(ModelMap model) {
		Todo todo = new Todo(Long.valueOf(0), "", String.valueOf(model.get("userName")), LocalDate.now().plusDays(30), LocalDate.now(), false);
		model.put("todo", todo);
		return "addTodo";
	}
	

	@RequestMapping(value = "addTodo", method = RequestMethod.POST)
	public String addNewTodo(ModelMap model, @Valid Todo todo, BindingResult result ) {
		if(result.hasErrors()) {
			return "addTodo";
		}
		todoService.addNewTodo(todo.getDescription(), String.valueOf(model.get("userName")), LocalDate.now().plusDays(30), LocalDate.now(), false);
		return "redirect:userTodos";
	}
	
	@RequestMapping("deleteTodo")
	public String deleteTodo(@RequestParam Long id) {
		todoService.deleteById(id);
		return "redirect:userTodos";
	}
	
	@RequestMapping(value = "updateTodo", method = RequestMethod.GET)
	public String showUpdateTodo(@RequestParam Long id, ModelMap model) {
		Todo todo = todoService.findById(id);
		model.addAttribute("todo", todo);
		return "addTodo";
	}
	
	@RequestMapping(value = "updateTodo", method = RequestMethod.POST)
	public String updateTodo(ModelMap model, @Valid Todo todo, BindingResult result) {
		if(result.hasErrors()) {
			return "addTodo"; 
		}
		String userName = String.valueOf(model.get("userName"));
		todo.setUserName(userName);
		todoService.updaetTodo(todo);
		return "redirect:userTodos";
	}
}
