package com.todoapp.springboot.todoapp.todo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.todoapp.springboot.todoapp.todo.schemaobjects.LogisticsObjectSO;
import com.todoapp.springboot.todoapp.todo.schemaobjects.SearchShipmentSO;

@Component
public class ShipmentRoleImpl {

	@Autowired
	private APIServiceInvoker serviceInvoker;
	
	public String saveShipment(String message) {
		return serviceInvoker.saveShipment(message);
	}

	public LogisticsObjectSO getShipment(SearchShipmentSO searchShipmentSO) {
		return serviceInvoker.getShipment(searchShipmentSO);
	}

}
