package com.todoapp.springboot.todoapp.todo;

import java.util.List;

public class AwbFlightDtls {

	private Long flightId;
	private String carrier;
	private String carNum;
	private String fromApt;
	private String toApt;
	private String deptDt;
	private String arrDt;
	private Long seqNum;
	private List<ScreeningSO> screeeningCheckList;
	private Boolean scrreningReq;
	public AwbFlightDtls() {
		// TODO Auto-generated constructor stub
	}
	
	public AwbFlightDtls(Long flightId, String carrier, String carNum, String fromApt, String toApt, String deptDt,
			String arrDt, Long seqNum, Boolean scrreningReq) {
		super();
		this.flightId = flightId;
		this.carrier = carrier;
		this.carNum = carNum;
		this.fromApt = fromApt;
		this.toApt = toApt;
		this.deptDt = deptDt;
		this.arrDt = arrDt;
		this.seqNum=seqNum;
		this.scrreningReq=scrreningReq;
	}

	public Long getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Long seqNum) {
		this.seqNum = seqNum;
	}

	public Long getFlightId() {
		return flightId;
	}
	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}
	public String getCarrier() {
		return carrier;
	}
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getFromApt() {
		return fromApt;
	}
	public void setFromApt(String fromApt) {
		this.fromApt = fromApt;
	}
	public String getToApt() {
		return toApt;
	}
	public void setToApt(String toApt) {
		this.toApt = toApt;
	}
	public String getDeptDt() {
		return deptDt;
	}
	public void setDeptDt(String deptDt) {
		this.deptDt = deptDt;
	}
	public String getArrDt() {
		return arrDt;
	}
	public void setArrDt(String arrDt) {
		this.arrDt = arrDt;
	}
	public List<ScreeningSO> getScreeeningCheckList() {
		return screeeningCheckList;
	}
	public void setScreeeningCheckList(List<ScreeningSO> screeeningCheckList) {
		this.screeeningCheckList = screeeningCheckList;
	}
	public Boolean getScrreningReq() {
		if(scrreningReq == null) {
			scrreningReq = Boolean.FALSE;
		}
		return scrreningReq;
	}
	public void setScrreningReq(Boolean scrreningReq) {
		this.scrreningReq = scrreningReq;
	}
	
	
}
