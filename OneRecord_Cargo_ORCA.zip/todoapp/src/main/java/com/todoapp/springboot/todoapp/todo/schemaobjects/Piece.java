package com.todoapp.springboot.todoapp.todo.schemaobjects;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonTypeName;

import ioinformarics.oss.jackson.module.jsonld.annotation.JsonldId;

@JsonPropertyOrder({"@id","@type"})
@JsonIgnoreProperties({"@type"})
@JsonTypeName("SecurityDeclaration")
public class Piece extends LogisticsObjectSO implements Serializable{

	private static final long serialVersionUID = 1l;
	@JsonldId
	private String id;
	private String goodsDescription;
	
}
